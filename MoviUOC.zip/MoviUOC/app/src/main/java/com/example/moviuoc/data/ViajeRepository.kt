package com.example.moviuoc.data

import android.content.Context

class ViajeRepository private constructor(private val dao: ViajeDao) {

    suspend fun insert(v: ViajeEntity) = dao.insert(v)
    fun observarTodos() = dao.observarTodos()

    companion object {
        @Volatile private var INSTANCE: ViajeRepository? = null
        fun get(context: Context): ViajeRepository =
            INSTANCE ?: synchronized(this) {
                val db = AppDatabase.get(context)
                ViajeRepository(db.viajeDao()).also { INSTANCE = it }
            }
    }
}
