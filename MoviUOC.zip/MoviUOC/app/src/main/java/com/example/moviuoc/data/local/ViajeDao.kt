package com.example.moviuoc.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ViajeDao {
    @Insert
    suspend fun insert(viaje: ViajeEntity)

    @Query("SELECT * FROM viajes ORDER BY fechaMillis DESC")
    fun observarTodos(): LiveData<List<ViajeEntity>>
}
