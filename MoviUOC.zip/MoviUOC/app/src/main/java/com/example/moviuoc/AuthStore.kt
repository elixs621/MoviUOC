package com.example.moviuoc

import android.content.Context

data class User(val email: String, val password: String, val name: String, val career: String)

object AuthStore {
    private const val PREFS = "auth_prefs"
    private const val LOGGED = "logged_in_email"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(email: String) = "user_" + email.trim().lowercase()

    fun saveUser(ctx: Context, user: User) {
        val packed = listOf(user.password, user.name, user.career).joinToString("|")
        prefs(ctx).edit().putString(key(user.email), packed).apply()
    }

    fun getUser(ctx: Context, email: String): User? {
        val raw = prefs(ctx).getString(key(email), null) ?: return null
        val parts = raw.split("|")
        if (parts.size < 3) return null
        return User(email.trim().lowercase(), parts[0], parts[1], parts[2])
    }

    fun login(ctx: Context, email: String, password: String): Boolean {
        val u = getUser(ctx, email) ?: return false
        val ok = u.password == password
        if (ok) prefs(ctx).edit().putString(LOGGED, u.email).apply()
        return ok
    }

    fun isLogged(ctx: Context): Boolean =
        prefs(ctx).getString(LOGGED, null) != null

    fun logout(ctx: Context) {
        prefs(ctx).edit().remove(LOGGED).apply()
    }
}
