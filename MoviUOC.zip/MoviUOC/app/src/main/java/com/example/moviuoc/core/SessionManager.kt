package com.example.moviuoc.core

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream

class SessionManager(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("movi_session", Context.MODE_PRIVATE)

    fun login(email: String, name: String) {
        prefs.edit()
            .putString("email", email)
            .putString("name", name)
            .putBoolean("logged", true)
            .apply()
    }

    fun isLogged(): Boolean = prefs.getBoolean("logged", false)
    fun email(): String = prefs.getString("email", "") ?: ""
    fun name(): String = prefs.getString("name", "") ?: ""
    fun photoPath(): String = prefs.getString("photoPath", "") ?: ""

    fun savePhoto(ctx: Context, bmp: Bitmap): String {
        val file = File(ctx.filesDir, "profile.jpg")
        FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 90, out) }
        prefs.edit().putString("photoPath", file.absolutePath).apply()
        return file.absolutePath
    }

    fun logout() {
        prefs.edit().clear().apply()
    }
}
