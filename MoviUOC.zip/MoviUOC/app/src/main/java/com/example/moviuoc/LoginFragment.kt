package com.example.moviuoc

import android.os.Bundle
import android.view.*
import android.widget.Button
import com.google.android.material.textfield.TextInputEditText
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.moviuoc.core.SessionManager
import android.widget.Toast

class LoginFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_login, c, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val session = SessionManager(requireContext())
        if (session.isLogged()) {
            findNavController().navigate(R.id.action_login_to_home)
            return
        }

        val etEmail = view.findViewById<TextInputEditText>(R.id.etEmail)
        val etPass  = view.findViewById<TextInputEditText>(R.id.etPass)
        val btnCont = view.findViewById<Button>(R.id.btnContinuar)
        val btnSign = view.findViewById<Button>(R.id.btnIrRegistro)

        btnCont.setOnClickListener {
            val email = etEmail.text?.toString()?.trim().orEmpty()
            val pass  = etPass.text?.toString()?.trim().orEmpty()

            if (email.endsWith("@duocuc.cl") && pass.length >= 4) {
                // DEMO: si ya se registró antes, usamos su nombre guardado; si no, ponemos uno por defecto
                val name = if (session.name().isNotBlank()) session.name() else "Estudiante DUOC"
                session.login(email, name)
                findNavController().navigate(R.id.action_login_to_home)
            } else {
                Toast.makeText(requireContext(), "Email @duocuc.cl y clave ≥4", Toast.LENGTH_SHORT).show()
            }
        }

        btnSign.setOnClickListener {
            findNavController().navigate(R.id.action_login_to_signup)
        }
    }
}
