package com.example.moviuoc

import android.os.Bundle
import android.view.*
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.example.moviuoc.core.SessionManager

class HomeFragment : Fragment() {

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View? {
        return i.inflate(R.layout.fragment_home, c, false)
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)

        val btnCrear = v.findViewById<Button>(R.id.btnCrearViaje)
        val btnBuscar = v.findViewById<Button>(R.id.btnBuscarViaje)
        val btnPerfil = v.findViewById<Button>(R.id.btnPerfil)
        val btnLogout = v.findViewById<Button>(R.id.btnCerrarSesion)

        btnCrear.setOnClickListener { findNavController().navigate(R.id.action_home_to_createTrip) }
        btnBuscar.setOnClickListener { findNavController().navigate(R.id.action_home_to_searchTrip) }
        btnPerfil.setOnClickListener { findNavController().navigate(R.id.action_home_to_profile) }

        btnLogout.setOnClickListener {
            SessionManager(requireContext()).logout()
            Toast.makeText(requireContext(), "Sesión cerrada", Toast.LENGTH_SHORT).show()

            val opts = NavOptions.Builder()
                .setPopUpTo(R.id.LoginFragment, inclusive = true)
                .build()
            // vamos a Login y limpiamos back stack
            findNavController().navigate(R.id.LoginFragment, null, opts)
        }
    }
}
