package com.example.moviuoc.ui.viaje

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.moviuoc.R
import com.example.moviuoc.data.ViajeEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ViajeAdapter :
    ListAdapter<ViajeEntity, ViajeAdapter.VH>(DIFF) {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTitulo: TextView = v.findViewById(R.id.tvTitulo)
        val tvDetalle: TextView = v.findViewById(R.id.tvDetalle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_viaje, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        holder.tvTitulo.text = "${item.origen} → ${item.destino}"
        holder.tvDetalle.text =
            "Fecha: ${sdf.format(Date(item.fechaMillis))} | Cupos: ${item.cupos} | \$${item.precio}"
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<ViajeEntity>() {
            override fun areItemsTheSame(o: ViajeEntity, n: ViajeEntity) = o.id == n.id
            override fun areContentsTheSame(o: ViajeEntity, n: ViajeEntity) = o == n
        }
    }
}
