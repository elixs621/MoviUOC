package com.example.moviuoc

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.*
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.moviuoc.core.SessionManager

class ProfileFragment : Fragment() {

    private lateinit var img: ImageView
    private lateinit var session: SessionManager

    private val takePhoto =
        registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp ->
            if (bmp != null) {
                val path = session.savePhoto(requireContext(), bmp)
                img.setImageBitmap(BitmapFactory.decodeFile(path))
            }
        }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View? {
        return i.inflate(R.layout.fragment_profile, c, false)
    }

    override fun onViewCreated(v: View, s: Bundle?) {
        super.onViewCreated(v, s)
        session = SessionManager(requireContext())

        img = v.findViewById(R.id.imgFoto)
        val tvNombre = v.findViewById<TextView>(R.id.tvNombre)
        val tvEmail  = v.findViewById<TextView>(R.id.tvEmail)
        val btnFoto  = v.findViewById<Button>(R.id.btnTomarFoto)

        tvNombre.text = "Nombre: ${session.name()}"
        tvEmail.text  = "Email: ${session.email()}"

        val p = session.photoPath()
        if (p.isNotBlank()) {
            img.setImageBitmap(BitmapFactory.decodeFile(p))
        }

        btnFoto.setOnClickListener {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
                takePhoto.launch(null)
            } else {
                ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.CAMERA), 1001)
            }
        }
    }
}
