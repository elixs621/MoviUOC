package com.example.moviuoc.data.local

class UserEntity {
}