package com.example.moviuoc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.moviuoc.data.ViajeEntity
import com.example.moviuoc.ui.viaje.ViajeViewModel
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class CreateTripFragment : Fragment() {

    private val vm: ViajeViewModel by viewModels()

    override fun onCreateView(
        i: LayoutInflater, c: ViewGroup?, s: Bundle?
    ): View = i.inflate(R.layout.fragment_create_trip, c, false)

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)

        // Referencias a inputs (IDs deben existir en fragment_create_trip.xml)
        val tilFecha: TextInputLayout = view.findViewById(R.id.tilFecha)
        val etFecha: TextInputEditText = view.findViewById(R.id.etFecha)
        val tilCupos: TextInputLayout = view.findViewById(R.id.tilCupos)
        val etCupos: TextInputEditText = view.findViewById(R.id.etCupos)
        val tilOrigen: TextInputLayout = view.findViewById(R.id.tilOrigen)
        val etOrigen: TextInputEditText = view.findViewById(R.id.etOrigen)
        val tilDestino: TextInputLayout = view.findViewById(R.id.tilDestino)
        val etDestino: TextInputEditText = view.findViewById(R.id.etDestino)
        val tilPrecio: TextInputLayout = view.findViewById(R.id.tilPrecio)
        val etPrecio: TextInputEditText = view.findViewById(R.id.etPrecio)

        val btnCrear: Button = view.findViewById(R.id.btnCrear)

        // Si no tienes aún selector de fecha, dejamos la actual como placeholder
        val ahora = Calendar.getInstance()
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        if (etFecha.text.isNullOrBlank()) {
            etFecha.setText(sdf.format(ahora.time))
        }

        btnCrear.setOnClickListener {
            // Validaciones simples
            var ok = true
            fun err(til: TextInputLayout, msg: String) {
                til.error = msg
                ok = false
            }
            tilFecha.error = null
            tilCupos.error = null
            tilOrigen.error = null
            tilDestino.error = null
            tilPrecio.error = null

            val fechaStr = etFecha.text?.toString()?.trim().orEmpty()
            val cuposStr = etCupos.text?.toString()?.trim().orEmpty()
            val origen = etOrigen.text?.toString()?.trim().orEmpty()
            val destino = etDestino.text?.toString()?.trim().orEmpty()
            val precioStr = etPrecio.text?.toString()?.trim().orEmpty()

            if (fechaStr.isEmpty()) err(tilFecha, "Requerido")
            if (cuposStr.isEmpty()) err(tilCupos, "Requerido")
            if (origen.isEmpty()) err(tilOrigen, "Requerido")
            if (destino.isEmpty()) err(tilDestino, "Requerido")
            if (precioStr.isEmpty()) err(tilPrecio, "Requerido")

            val fechaMillis = runCatching {
                sdf.parse(fechaStr)!!.time
            }.getOrElse {
                err(tilFecha, "Fecha inválida (usa dd/MM/yyyy HH:mm)")
                -1L
            }

            val cupos = cuposStr.toIntOrNull() ?: run {
                err(tilCupos, "Debe ser número")
                -1
            }

            val precio = precioStr.toIntOrNull() ?: run {
                err(tilPrecio, "Debe ser número")
                -1
            }

            if (!ok) return@setOnClickListener

            // Guarda en Room
            val viaje = ViajeEntity(
                fechaMillis = fechaMillis,
                cupos = cupos,
                origen = origen,
                destino = destino,
                precio = precio
            )
            vm.insert(viaje)

            // Volver atrás
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
    }
}
