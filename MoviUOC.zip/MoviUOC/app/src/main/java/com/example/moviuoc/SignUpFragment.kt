package com.example.moviuoc

import android.os.Bundle
import android.view.*
import android.widget.Button
import com.google.android.material.textfield.TextInputEditText
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.moviuoc.core.SessionManager
import android.widget.Toast

class SignUpFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_sign_up, c, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val etEmail = view.findViewById<TextInputEditText>(R.id.etEmail)
        val etPass  = view.findViewById<TextInputEditText>(R.id.etPass)
        val etName  = view.findViewById<TextInputEditText>(R.id.etName)
        val btnReg  = view.findViewById<Button>(R.id.btnRegistrar)

        btnReg.setOnClickListener {
            val email = etEmail.text?.toString()?.trim().orEmpty()
            val pass  = etPass.text?.toString()?.trim().orEmpty()
            val name  = etName.text?.toString()?.trim().orEmpty()

            if (email.endsWith("@duocuc.cl") && pass.length >= 4 && name.isNotBlank()) {
                SessionManager(requireContext()).login(email, name)
                Toast.makeText(requireContext(), "Cuenta creada", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.action_signup_to_login)
            } else {
                Toast.makeText(requireContext(),"Completa datos válidos (@duocuc.cl, pass ≥4)",Toast.LENGTH_SHORT).show()
            }
        }
    }
}
